#!/bin/bash
set -e 

dir=$(pwd)
base=busybox-1.14.1
src=${base}.tar.gz
export PATH=$PATH:${dir}/arm-2010q1/bin

function clean()
{
	rm -rf ${base} || true
	echo "===== Clean done ====="
}

if [ "X$1" = "Xclean" ] ; then
	clean && exit 0 
fi

if [ ! -d $base ] ; then
	clean
	tar xfz $src
	echo "===== Extract done ====="
fi

cp busybox-1.14.1.config $base/.config
cd $base

make CROSS_COMPILE=arm-none-linux-gnueabi- -j6 $*
echo "===== Compilation done done ::: Use $base/busybox ====="


