=====================================
 How to build busybox 1.14.1, 1.14.3
=====================================

1. Move to your busybox directory, busybox/1_14_1/ or busybox/1_14_3
 
2. get Toolchain
	Visit http://www.codesourcery.com/, download and install Sourcery G++ Lite 2010q1-202 toolchain for ARM EABI.
	Extract toolchain at busybox/1_14_1/arm-2010q1 or busybox/1_14_3/arm-2010q1
	
	If toolchain is extracted other place, please modify PATH in ./compile.sh
	
	default : export PATH=$PATH:${dir}/arm-2010q1/bin
	modify  : export PATH=$PATH:$[YOUR TOOLCHAIN PATH] 

3. Excute build script
  ./compile.sh
 
4. Use busybox-1.14.1/busybox or busybox-1.14.3/busybox.

# busybox 1.14.1 for kernel, busybox 1.14.3 for AP side on Modem.
